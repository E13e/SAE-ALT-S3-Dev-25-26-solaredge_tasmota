<?php require_once('./include/head.php'); ?>


<!-- partie body -->
<?php require_once('./include/header.php'); ?>

<!-- Conteneur principal -->
<div class="container-fluid flex-grow-1">
    <div class="row">

        <!-- partie menu -->
        <?php require_once('./include/menu.php'); ?>

        <!-- partie contenu principal -->
        <main role="main" class="col-md-9 ms-sm-auto col-lg-10 px-4">
            <center>
                
                <H1> Retrouvez les exercices dans le menu </H1>
            </center>
	</main>

    </div>
</div>

<!-- Pied de page & fin html -->
<?php require_once('./include/footer.php'); ?>