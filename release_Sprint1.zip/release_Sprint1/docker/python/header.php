<body class="d-flex flex-column min-vh-100">
    <header class="bg-primary text-white text-center py-1">
        <div class="container">
            <h1> Médiatheque de l'IUT de Blagnac</h1>
        </div>
    </header>