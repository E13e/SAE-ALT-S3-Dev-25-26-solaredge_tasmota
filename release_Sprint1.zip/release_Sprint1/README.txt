# Sprint 1

## Fonctionnalités implementées

Il est possible de lancer le projet docker à l'aide des commandes présentes dans le fichier [cmd_docker.txt](https://github.com/E13e/SAE-ALT-S3-Dev-25-26-solaredge_tasmota/blob/main/cmd_docker.txt) (présent dans le zip). /!\ Ces commandes doivent être entrée dans le répertoire docker /!\. Une fois lancée les données des panneaux solaires sont accessibles via ce lien http://127.0.0.1:8080/php/.


Si vous avez le moindre soucis, vous pouvez aller voir dans la [documentation utilisateur](https://github.com/E13e/SAE-ALT-S3-Dev-25-26-solaredge_tasmota/blob/main/gpo/docs/doc_utilisateur.adoc) ou encore, dans une moindre mesure, [le cahier de test](https://github.com/E13e/SAE-ALT-S3-Dev-25-26-solaredge_tasmota/blob/main/gpo/docs/carnet_test.adoc).

## En cas de problème

Vous pouvez contacter une de ces trois adresses mail :

    - guillaume.larroutis@etu.univ-tlse2.fr

    - jeremy.ratsimba@etu.univ-tlse2.fr

    - alexis.dupont@etu.univ-tlse2.fr
